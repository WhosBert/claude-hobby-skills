# Brew Day Recipe Calculator: a free skill for Claude, ChatGPT, Gemini and Grok

A small skill that takes your recipe and works out estimated OG, FG, ABV, IBU and color, shows the working and compares it to your target style.

- Gravity, ABV, IBU and color
- Formulas shown
- Style check with simple fixes

Made by [Brew Day](https://brew.whatiflabs.ai/?utm_source=github&utm_medium=referral&utm_campaign=free-skills), part of [What If Labs](https://whatiflabs.ai/projects/skill-stores).

## Install it

1. Download [brew-day-recipe-calc.zip](../../dist/brew-day-recipe-calc.zip) (don't unzip it).
2. In Claude on the web or desktop, open **Customize**, then **Skills**, click **+**, choose **Upload a skill** and pick the ZIP.
3. Make sure code execution is on in **Settings**, **Capabilities**. It works on any Claude plan, including the free one.
4. Ask Claude something in plain words. It picks the skill up on its own.

Using ChatGPT? Go to **Skills** (chatgpt.com/skills), click **Add**, choose **Upload from your computer** and pick the same ZIP. Use it in **Work** mode: skills don't run in plain Chat mode.

Using Gemini or Grok? Open **Skills** at gemini.google.com or grok.com and upload the same ZIP.

Using Claude Code, Codex, Cursor, Gemini CLI or another coding agent? Copy this folder into that tool's skills folder, for example `~/.claude/skills/`.

## Try a free tool first

No AI app needed: the [ABV and Priming Sugar Calculator for Homebrew](https://brew.whatiflabs.ai/abv-priming-calculator?utm_source=github&utm_medium=referral&utm_campaign=free-skills) runs in your browser and shows its working.

## Want the whole thing?

The [Brew Day Brewing Companion](https://brew.whatiflabs.ai/?utm_source=github&utm_medium=referral&utm_campaign=free-skills) is $15, one time, with a 14-day refund. Design, brew, ferment, package and troubleshoot.

- Recipe design to style
- Scaling and extract conversion
- Timed brew day schedule
- Water and mash chemistry
- Yeast and fermentation plans
- Priming sugar and keg pressure
- Off-flavour troubleshooting
- Updates for a year

## License

MIT. Use it, change it, share it. Please keep the credit to Brew Day.
