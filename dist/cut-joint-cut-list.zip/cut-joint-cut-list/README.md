# Cut & Joint Cut List: a free skill for Claude, ChatGPT, Gemini and Grok

A small skill that turns a simple project (box, shelf, bookcase, bench, frame) into a cut list and a board-foot or plywood estimate.

- Parts grouped by assembly
- Board feet with waste allowance
- Plywood sheet count with kerf

Made by [Cut & Joint](https://wood.whatiflabs.ai/?utm_source=github&utm_medium=referral&utm_campaign=free-skills), part of [What If Labs](https://whatiflabs.ai/projects/skill-stores).

## Install it

1. Download [cut-joint-cut-list.zip](../../dist/cut-joint-cut-list.zip) (don't unzip it).
2. In Claude on the web or desktop, open **Customize**, then **Skills**, click **+**, choose **Upload a skill** and pick the ZIP.
3. Make sure code execution is on in **Settings**, **Capabilities**. It works on any Claude plan, including the free one.
4. Ask Claude something in plain words. It picks the skill up on its own.

Using ChatGPT? Go to **Skills** (chatgpt.com/skills), click **Add**, choose **Upload from your computer** and pick the same ZIP. Use it in **Work** mode: skills don't run in plain Chat mode.

Using Gemini or Grok? Open **Skills** at gemini.google.com or grok.com and upload the same ZIP.

Using Claude Code, Codex, Cursor, Gemini CLI or another coding agent? Copy this folder into that tool's skills folder, for example `~/.claude/skills/`.

## Try a free tool first

No AI app needed: the [Board Foot Calculator with Waste and Cost](https://wood.whatiflabs.ai/board-foot-calculator?utm_source=github&utm_medium=referral&utm_campaign=free-skills) runs in your browser and shows its working.

## Want the whole thing?

The [Cut & Joint Shop Planner](https://wood.whatiflabs.ai/?utm_source=github&utm_medium=referral&utm_campaign=free-skills) is $15, one time, with a 14-day refund. Design, cut, build and finish with fewer mistakes.

- Design check with wood movement math
- Joinery choice and sizing
- Cut lists with rough and final sizes
- Plywood layouts and board-foot shopping lists
- Step-by-step build sequence
- Finishing schedules, food-safe and outdoor
- Updates for a year

## License

MIT. Use it, change it, share it. Please keep the credit to Cut & Joint.
